
Brief:
Console application built in .Net C# code that uses a Json file to get monthly text message bills
based on the account holder, month, and year.  

Packages installed:
- Newtonsoft.Json

Instructions:

1. Please run the TextMessage.csproj file

2. Please enter customer account number when prompted (sample data can be found in data/accounts.json file)

3. Please enter month number

4. Please enter year

5. Result should be displayed on the console

I got a bit stuck on the formula when calculating the final bill so I did a basic multiplication of the total texts 
by the price band it falls into.

