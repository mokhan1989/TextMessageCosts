﻿/*
 * Author: Mohammad Hyderkhan
 * Date: 30/09/2019
 * Description: A console application calculate the bill for the total amount of text messages sent by an account holder for a given month
 * Release version: v1.0
*/

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextMessageCosts
{
    public interface ITotalCostCalculator
    {
        // Calculate the total cost for the month from the text message usage

        decimal CalculateCost(int textMessagesSent);
    }

    public interface IAccountDetails
    {
        // Returns the number of message for the specified customer and month
        int customerAccount { get; set; }
        int monthNo { get; set; }
        int yearNo { get; set; }

        // Number of the text messages sent.
        string NumberOfTextMessagesSentInMonth(int customerAccount, int monthNo, int yearNo);

    }

    public class MonthlyBill: ITotalCostCalculator, IAccountDetails
    {
        public int customerAccount { get; set; }
        public int monthNo { get; set; }
        public int yearNo { get; set; }

        // Method to fetch total number of messages
        public string NumberOfTextMessagesSentInMonth(int customerAccount, int monthNo, int yearNo)
        {

            string filepath = "../../data/accounts.json";
            string result = null;
            using (StreamReader r = new StreamReader(filepath))
            {
                // Deserialize JSON object
                var json = r.ReadToEnd().ToString();
                dynamic obj = JsonConvert.DeserializeObject(json);

                // Loop through each account in data/Accounts.json
                foreach(var account in obj.Accounts)
                {
                    //If record matches user input
                    if(account.customerAccount == customerAccount && account.monthNo == monthNo && account.yearNo == yearNo)
                    {
                        // Append json value to result variable
                        result = account.numberOfMessages;
                    }
                    
                }

            }

            return result;
        }

        // Method to calculate total monthly costs
        public decimal CalculateCost(int textMessagesSent)
        {
            string filepath = "../../data/price-bands.json";
            decimal totalMonthlyCost = 0;

            using (StreamReader r = new StreamReader(filepath))
            {
                // Deserialize object
                var json = r.ReadToEnd().ToString();
                dynamic obj = JsonConvert.DeserializeObject(json);

                // Loop through each price bands in data/price-bands.json
                foreach(var price in obj.PriceBands)
                {
                    // Convert json strings into integers
                    int fromInteger = Convert.ToInt32(price.QtyFrom);
                    int toInteger = Convert.ToInt32(price.QtyTo);
                    decimal priceDecimal = Convert.ToDecimal(price.PricePerTextMessage);

                    if(textMessagesSent > 1000)
                    {
                        totalMonthlyCost = Convert.ToDecimal(textMessagesSent * 0.03);
                    }

                    // If total text messages sent falls within a price brand
                    else if(textMessagesSent >= fromInteger && textMessagesSent <= toInteger)
                    {
                        // Multiply total messages sent by price band value
                        totalMonthlyCost = textMessagesSent * priceDecimal;

                    }

                }

            }

            return totalMonthlyCost;
        }

    }

    public class PriceBands
    {
        public int QtyFrom { get; set; }
        public int? QtyTo { get; set; }
        public decimal PricePerTextMessage { get; set; }

    }

    class Program
    {
        static void Main(string[] args)
        {
            // User Input
            int customerAccount;
            Console.Write("Enter customer account number: ");            
            customerAccount = Convert.ToInt32(Console.ReadLine());
 
            int monthNo;
            Console.Write("Enter month number: ");
            monthNo = Convert.ToInt32(Console.ReadLine());

            int yearNo;
            Console.Write("Enter year: ");
            yearNo = Convert.ToInt32(Console.ReadLine());

           //Fetch total text messages sent based on user's search query
            MonthlyBill Query = new MonthlyBill();
       
                var monthlyTextMessages = Query.NumberOfTextMessagesSentInMonth(customerAccount, monthNo, yearNo);

                if (monthlyTextMessages == null)
                {
                    Console.WriteLine("No results found");
                }
                else 
                {
                    //Pass the total amount of messages to calculate total cost
                    var totalCost = Query.CalculateCost(Convert.ToInt32(monthlyTextMessages));

                    //Output result
                    Console.WriteLine("The monthly bill to be paid is £" + totalCost);
                }

                Console.ReadKey();
  
        }
    }
}
